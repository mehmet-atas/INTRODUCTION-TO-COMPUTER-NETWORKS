% Mehmet Ataş
clc;
clear;
close all;
open_system('tcp_server')

sim_time_step = 0.01;

% start the simulation and pause the simulation, waiting for singal from python
set_param(gcs,'SimulationCommand','start','SimulationCommand','pause');

% open a server, it will block until a client connect to it
s = tcpip('127.0.0.1', 6002,  'NetworkRole', 'server');
fopen(s);

info = [];
c=0;
% main loop
while c<10   
    while 1 
        nBytes = get(s,'BytesAvailable');
        if nBytes>0
            break;
        end
    end
    command = fread(s,nBytes); % fread() will read binary as str
    
    data=str2num(char(command')); % tranform str into numerical matrix
    
    info = [info;data]; % store history data
    if isempty(data)
        data=[0,0,0,0,0,0,0,0,0,0];
    end
    data1 = data(1); 
    data2 = data(2); 
    data3 = data(3); 
    data4 = data(4);
    data5 = data(5);
    data6 = data(6);
    data7 = data(7);
    data8 = data(8);
    data9 = data(9);
    data10 = data(10);
    
    % set a paramter in the simulink model using the data get from python
    set_param('tcp_server/K1','Gain',num2str(data1))
    set_param('tcp_server/K2','Gain',num2str(data2))
    set_param('tcp_server/K3','Gain',num2str(data3))
    set_param('tcp_server/K3','Gain',num2str(data4))
    set_param('tcp_server/K3','Gain',num2str(data5))
    set_param('tcp_server/K3','Gain',num2str(data6))
    set_param('tcp_server/K3','Gain',num2str(data7))
    set_param('tcp_server/K3','Gain',num2str(data8))
    set_param('tcp_server/K3','Gain',num2str(data9))
    set_param('tcp_server/K3','Gain',num2str(data10))
    % run the simulink model for one step
    set_param(gcs, 'SimulationCommand', 'step');  
    
    u=states.data(end,:); % read the last data in the result array 
    fwrite(s, jsonencode(u)); % encode data using json
    c=ct+1;
end
fclose(s);
set_param(gcs,'SimulationCommand','stop');