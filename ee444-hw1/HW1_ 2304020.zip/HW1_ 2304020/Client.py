# EE444 HW1 Mehmet Ataş - 2304020
import socket
import time
# IP address and port number for loopback
HOST = '127.0.0.1'
# For Proxy.
PORT = 6002 
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((HOST,PORT))
# The program's opening message.
print("Please enter the messages to be delivered to the proxy server. \n")  

# We can start an infinite loop for primary operations.
while True:

    # Reset the variables' values
    OperatingCode = ""
    numberofindex = ""
    data = ""

    # Get the user's feedback. The OP Code must be specified by the user.
    OperatingCode = input(" Please write OP=ADD, OP=GET, OP=PUT, OP=CLR.\n")
    
   # ADD
     if( OperatingCode == "OP=ADD"):
        numberofindex = input(" Please enter the index numbers you wish to add together.\n")
        message = "OP=" + OperatingCode + ";IND=" + numberofindex + ";DATA=;"
   # GET
    elif( OperatingCode == "OP=GET"):
        numberofindex = input(" Please enter the index numbers you wish to get together. \n")
        message = "OP=" + OperatingCode + ";IND=" + numberofindex + ";DATA=;"
    # PUT
    elif( OperatingCode == "OP=PUT"):
        numberofindex = input(" Please enter the index numbers you wish to put. \n")
        data = input(" Please enter the values you wish to put in indexes.\n")
        message = "OP=" + OperatingCode + ";IND=" + numberofindex + ";DATA=" + data + ";"
    # CLR
    elif( OperatingCode == "OP=CLR"):
        message = "OP=" + OperatingCode + ";IND=;DATA=;"

    # This function forwards the messages to the proxy.
    client_socket.sendall(bytes(message,'utf-8'))
    time.sleep(1)
    print("The message transmitted to proxy: " + message) 

    # We must additionally obtain proxy response messages. The answer is only accepted by get and add operations.

    # GET
    if( OperatingCode == "OP=GET"):
        response = client_socket.recv(1024)
        response = response.decode('utf-8')
        print ("\n Received response:" + response)
        # Get the response message and convert the byte to string.
        #  Using the split function, remove the OP and IND fields. As a result, the required DATA field may be viewed.
        response_info = response.split(";",2)[2]
        response_info = response_info.split(";",2)[0]
        print(response_info)

    # ADD
    elif( OperatingCode == "OP=ADD"):
        response = client_socket.recv(1024)
        response = response.decode('utf-8')
        print ("\n RESPONSE:" + response)
        # Get the response message and convert the byte to string.
        #  Using the split function, remove the OP and IND fields. As a result, the required DATA field may be viewed.
        response_info = response.split(";",2)[2]
        response_info = response_info.split(";",2)[0]
        print(response_info)

    # PUT
    elif( OperatingCode == "OP=PUT"):
        response = client_socket.recv(1024)
        response = response.decode('utf-8')
        print ("\n Received response:" + response)
        # Get the response message and convert the byte to string.

    # GET 
    elif( OperatingCode == "OP=CLR"):
        response = client_socket.recv(1024)
        response = response.decode('utf-8')
        print ("\n Received response:" + response)
        # Get the response message and convert the byte to string.
        