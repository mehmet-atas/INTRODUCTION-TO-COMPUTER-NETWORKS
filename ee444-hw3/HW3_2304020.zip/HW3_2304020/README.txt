1.question 1.part --> try
1.question 2.part --> trysecond
2.question 1.part --> trythird
